package Spclass;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import Spclass.Book;

public class SpringFirstType {

	public static void main(String[] args) {
		Resource r=new ClassPathResource("Spclass/springconfig.xml");
		BeanFactory b=new XmlBeanFactory(r);
		Book book=(Book)b.getBean("s1");	
		System.out.println("Book Id :"+book.getBook_id());
		System.out.println("Book Name :"+book.getBook_name());
		System.out.println("Book Author :"+book.getAuthor());
	}
}
